//
//  ViewController.m
//  Gravity and Collisions
//
//  Created by Leonardeta on 18/10/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *bwFootball;
@property (weak, nonatomic) IBOutlet UIImageView *redFootball;
@property (strong, nonatomic) UIDynamicAnimator *animator;
@property (strong, nonatomic) UIGravityBehavior *gravity;
@property (strong, nonatomic) UICollisionBehavior *collision;
@property (strong, nonatomic) UIDynamicItemBehavior *behaviour;
@property (weak, nonatomic) IBOutlet UIImageView *grass;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.animator=[[UIDynamicAnimator alloc]initWithReferenceView:self.view];
    self.gravity=[[UIGravityBehavior alloc] initWithItems:@[self.bwFootball, self.redFootball]];
    [self.animator addBehavior:self.gravity];
    
    self.collision=[[UICollisionBehavior alloc] initWithItems:@[self.bwFootball, self.redFootball]];
    self.collision.translatesReferenceBoundsIntoBoundary=YES;
    CGPoint rightEdge=CGPointMake(self.grass.frame.origin.x+self.grass.frame.size.width, self.grass.frame.origin.y);
    [self.collision addBoundaryWithIdentifier:@"grass" fromPoint:self.grass.frame.origin toPoint:rightEdge];
    [self.animator addBehavior:self.collision];
    
    self.behaviour=[[UIDynamicItemBehavior alloc]initWithItems:@[self.bwFootball]];
    self.behaviour.elasticity=0.7;
    [self.animator addBehavior:self.behaviour];
    
  //  self.collision=[[UICollisionBehavior alloc]initWithItems:@[self.bwFootball, self.grass]];
    
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
