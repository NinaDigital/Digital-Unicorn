//
//  AppDelegate.h
//  Weekly Menu planning
//
//  Created by Leonardeta on 23/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property NSMutableDictionary *shoppingList;
@property NSMutableDictionary *recipies;
@property NSMutableArray *mealPlan;
@property NSMutableArray *recipeNames;
@property NSArray *shoppingItems;
@property NSArray *shoppingUnits;

@end

