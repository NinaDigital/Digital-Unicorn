//
//  FirstCustomSegue.swift
//  Custom Segues
//
//  Created by Leonardeta on 08/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

import UIKit

class FirstCustomSegue: UIStoryboardSegue {

    override func perform() {
        let firstVCView=self.source.view
        let secondVCView=self.destination.view
        let screenWidth=UIScreen.main.bounds.size.width
        let screenHeight=UIScreen.main.bounds.size.height
        secondVCView!.frame=CGRect(x: 0.0, y: screenHeight, width: screenWidth, height: screenHeight)
        let window = UIApplication.shared.keyWindow
        window?.insertSubview(secondVCView!, aboveSubview: firstVCView!)
        
        UIView.animate(withDuration: 0.4, animations: {()-> Void in
        firstVCView!.frame=firstVCView!.frame.offsetBy(dx: 0.0, dy: -screenHeight)
        secondVCView!.frame=secondVCView!.frame.offsetBy(dx: 0.0, dy: -screenHeight)
        })
        {(Finished)-> Void in
        self.source.present(self.destination as UIViewController, animated:  false, completion: nil)
        }
    }
   
    
    
}
