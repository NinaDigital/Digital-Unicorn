//
//  PlayingCarHeaderCollectionReusableView.m
//  Collections
//
//  Created by Leonardeta on 05/10/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "PlayingCardHeader.h"

@implementation PlayingCardHeader
-(void) setDeckText:(NSString *)text
{
    self.deckLabel.text=text;
    NSString *imageName=[NSString stringWithFormat:@"%@.png", text];
    
    UIImage *cardImage=[UIImage imageNamed:imageName];
    self.suitImageView.image=cardImage;
}

@end
