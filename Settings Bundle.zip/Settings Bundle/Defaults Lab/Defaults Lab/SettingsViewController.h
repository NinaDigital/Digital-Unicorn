//
//  SettingsViewController.h
//  Defaults Lab
//
//  Created by Leonardeta on 24/10/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsViewController : UITableViewController

@end
