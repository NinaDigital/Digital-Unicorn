//
//  MenuDetailsViewController.h
//  Weekly Meal Planning
//
//  Created by Leonardeta on 23/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Social/Social.h>
#import <Accounts/Accounts.h>

@interface MenuDetails : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *myRecipeTitle;
@property (weak, nonatomic) IBOutlet UIImageView *myBigImage;
@property (weak, nonatomic) IBOutlet UITextView *myIngredients;
@property (weak, nonatomic) IBOutlet UITextView *myMethod;
@property (strong,nonatomic) NSDictionary *recipe;
@property (strong,nonatomic) NSString  *recipeTitle;

@end
