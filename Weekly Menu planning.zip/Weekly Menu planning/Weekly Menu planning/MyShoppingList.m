//
//  MyShoppingList.m
//  Weekly Menu planning
//
//  Created by Leonardeta on 30/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "MyShoppingList.h"
#import "AppDelegate.h"

@interface MyShoppingList ()
{
    NSMutableDictionary *recipies;
    NSMutableDictionary *shoppingList;
    NSArray *recipeNames;
    NSMutableArray *shoppingItemNames;
    NSMutableArray *shoppingItemQuantityAndUnit;
     
   }

@property NSMutableArray *sections;
@property NSIndexPath *selectedIndexPath;

@property NSMutableArray *rows;
@property (strong, nonatomic) IBOutlet UITableView *table;

@end

@implementation MyShoppingList

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.leftBarButtonItem = self.editButtonItem;
    UIBarButtonItem *saveButton = [[UIBarButtonItem alloc] initWithTitle:@"Save" style:UIBarButtonItemStyleDone target:self action:@selector(saveClicked:)];
        self.navigationItem.rightBarButtonItem = saveButton;
    

   
    shoppingList = ((AppDelegate *)[UIApplication sharedApplication].delegate).shoppingList;
   
    NSMutableArray *rows = [[NSMutableArray alloc] initWithCapacity:0];
    self.sections = [@[rows] mutableCopy];
    
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}
-(void)viewDidAppear:(BOOL)animated
{
    shoppingItemNames = [[shoppingList allKeys] mutableCopy];
    shoppingItemQuantityAndUnit = [[shoppingList allValues] mutableCopy];
    NSLog(@"%@",shoppingItemQuantityAndUnit);
    [self.table reloadData];
}

-(void)viewWillAppear:(BOOL)animated
{
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [shoppingList count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *simpleTableIdentifier = @"shoppingCell";
    
    ShoppingListCell *cell = (ShoppingListCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];

    
    UILabel *itemName=(UILabel *) [cell viewWithTag:1];
    itemName.text = shoppingItemNames[indexPath.row];
    
    UILabel *itemAmount=(UILabel *) [cell viewWithTag:2];
    itemAmount.text = [NSString stringWithFormat:@"%@", shoppingItemQuantityAndUnit[indexPath.row][0]];
    
    UILabel *itemUnit=(UILabel *) [cell viewWithTag:3];
    itemUnit.text = shoppingItemQuantityAndUnit[indexPath.row][1];
   
   return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        
    NSString *shoppingListKey = shoppingItemNames[indexPath.row];

    [shoppingItemNames removeObjectAtIndex:indexPath.row];
    [shoppingList removeObjectForKey:shoppingListKey];
    [shoppingItemQuantityAndUnit removeObjectAtIndex:indexPath.row];
    
    [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    [tableView reloadData];
    }
}

-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

-(void)saveClicked:(id)sender
{
    UIAlertController *myAlert=[UIAlertController alertControllerWithTitle:@"My Shopping List" message:@"Do you want to print it or to send it via email?" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *print=[UIAlertAction actionWithTitle:@"Print" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
                       {
                           UIPrintInteractionController *myPrintController=[UIPrintInteractionController sharedPrintController];
                           
                           UIPrintInfo *myPrintInfo=[UIPrintInfo printInfo];
                           myPrintInfo.outputType=UIPrintInfoOutputGeneral;
                           myPrintInfo.jobName=@"Print View";
                           myPrintController.printInfo=myPrintInfo;
                           
                           myPrintController.showsPageRange=YES;
                           
                           UIGraphicsBeginImageContext(self.view.bounds.size);
                           
                           [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
                           
                           UIImage *myImage=UIGraphicsGetImageFromCurrentImageContext();
                           UIGraphicsEndImageContext();
                           
                           myPrintController.printingItem=myImage;
                           
                           void (^completionHandler)(UIPrintInteractionController *, BOOL, NSError *)=
                           ^(UIPrintInteractionController *print, BOOL completed, NSError *error)
                           
                           {
                               if (!completed && error)
                               {NSLog(@"Error!");}
                           };
                           [myPrintController presentAnimated:YES completionHandler:completionHandler];
                       }];
    
    UIAlertAction *email=[UIAlertAction actionWithTitle:@"Email" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
                       {
                        NSMutableString *myMessage = [NSMutableString stringWithCapacity:0];
                        for (int i = 0; i<[shoppingItemNames count]; i++)
                        {
                        myMessage = [NSMutableString stringWithFormat:@"<html><i>%@ %d) %@ %@<br></html>"
                        ,myMessage, i, shoppingItemNames[i],shoppingItemQuantityAndUnit[i]];
                        }

                        MFMailComposeViewController *myMailer=[[MFMailComposeViewController alloc]init];
                        myMailer.mailComposeDelegate=self;
                        [myMailer setSubject:@"My Shopping List"];
                        [myMailer setMessageBody:myMessage isHTML:YES];
                        [myMailer setModalPresentationStyle:UIModalPresentationFormSheet];
                        [self presentViewController:myMailer animated:YES completion:nil];
                           
                          }];
    
    UIAlertAction *cancel=[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action)
                           {}];
    
    [myAlert addAction:print];
    [myAlert addAction:email];
    [myAlert addAction:cancel];
    
    [self presentViewController:myAlert animated:YES completion:nil];
}

- (void)mailComposeController:(MFMailComposeViewController*)controller
          didFinishWithResult:(MFMailComposeResult)result
                        error:(NSError*)error
{
    [self dismissViewControllerAnimated:YES completion:nil];
    return;
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

-(BOOL) validateEmailAddress: (NSString *)yourEmail
{
    NSString *emailRegex=@"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *email=[NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [email evaluateWithObject:yourEmail];
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


@end
