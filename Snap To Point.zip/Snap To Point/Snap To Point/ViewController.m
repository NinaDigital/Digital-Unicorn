//
//  ViewController.m
//  Snap To Point
//
//  Created by Leonardeta on 18/10/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIView *myView;
@property CGPoint previousTouchPoint;
@property BOOL draggingView;
@property (strong, nonatomic) UIGravityBehavior *gravity;
@property (strong, nonatomic) UIDynamicAnimator *animator;
@property (strong, nonatomic) UICollisionBehavior *collision;
@property (strong, nonatomic) UIDynamicItemBehavior *behavior;
@property (strong, nonatomic) UISnapBehavior *snap;
@property BOOL viewSnapped;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIPanGestureRecognizer *panGesture=[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    [self.myView addGestureRecognizer:panGesture];
    
    self.animator=[[UIDynamicAnimator alloc] initWithReferenceView:self.view];
    self.gravity=[[UIGravityBehavior alloc]initWithItems:@[self.myView]];
    self.gravity.magnitude=4.0f;
    self.collision=[[UICollisionBehavior alloc]initWithItems:@[self.myView]];
    [self.animator addBehavior:self.collision];
    
    self.behavior=[[UIDynamicItemBehavior alloc]initWithItems:@[_myView]];
    self.behavior.elasticity=0.7;
    self.behavior.allowsRotation=NO;
    
    float boundary=self.myView.frame.origin.y+self.myView.frame.size.height+1;
    CGPoint boundaryStart=CGPointMake(0, boundary);
    CGPoint boundaryEnd=CGPointMake(self.view.bounds.size.width, boundary);
    [self.collision addBoundaryWithIdentifier:@1 fromPoint:boundaryStart toPoint:boundaryEnd];
    
    [self.animator addBehavior:self.behavior];
    [self.animator addBehavior:self.gravity];
    [self.animator addBehavior:self.collision];
    
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)handlePan:(UIGestureRecognizer *) gesture
{
    CGPoint touchPoint=[gesture locationInView:self.view];
    UIView *draggedView=gesture.view;
    if(gesture.state==UIGestureRecognizerStateBegan)
    {
        CGPoint dragStartLocation=[gesture locationInView:draggedView];
        if (dragStartLocation.y<draggedView.frame.size.height)
        {
            self.draggingView=YES;
            self.previousTouchPoint=touchPoint;
        }
    }
    else if (gesture.state==UIGestureRecognizerStateChanged && self.draggingView)
    {
        float yOffset=self.previousTouchPoint.y-touchPoint.y;
        if (touchPoint.y<self.view.frame.size.height-draggedView.frame.size.height)
        {
            gesture.view.center=CGPointMake(draggedView.center.x, draggedView.center.y-yOffset);
            self.previousTouchPoint=touchPoint;
        }
    }
else if (gesture.state==UIGestureRecognizerStateEnded && self.draggingView)
    {
        _draggingView=NO;
        [self.animator updateItemUsingCurrentState:draggedView];
        [self tryToSnap:draggedView];
    }
}

-(void) tryToSnap: (UIView *)view
{

    BOOL viewHasReachedDockLocation=view.frame.origin.y<100;
    if (viewHasReachedDockLocation)
    {
    if (!self.viewSnapped)
    {
        self.snap=[[UISnapBehavior alloc] initWithItem:view snapToPoint:CGPointMake(160, 90)];
        [self.animator addBehavior:self.snap];
        self.viewSnapped=YES;
    }
    }
    else
    {
    if (self.viewSnapped)
    {
        [self.animator removeBehavior:self.snap];
        self.viewSnapped=NO;
    }
    }
}

@end
