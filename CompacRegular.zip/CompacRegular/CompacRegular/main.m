//
//  main.m
//  CompacRegular
//
//  Created by Leonardeta on 28/09/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        
    }
    return 0;
}
