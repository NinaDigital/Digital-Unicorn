//
//  ShoppingListCell.m
//  Weekly Menu planning
//
//  Created by Leonardeta on 30/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "ShoppingListCell.h"

@implementation ShoppingListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
