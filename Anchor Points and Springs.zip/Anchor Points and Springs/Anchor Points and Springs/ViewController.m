//
//  ViewController.m
//  Anchor Points and Springs
//
//  Created by Leonardeta on 18/10/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *bwFootball;
@property (weak, nonatomic) IBOutlet UIImageView *redFootball;
@property (strong, nonatomic) UIDynamicAnimator *animator;
@property (strong, nonatomic) UIGravityBehavior *gravity;
@property (strong, nonatomic) UICollisionBehavior *collision;
@property (strong, nonatomic) UIAttachmentBehavior *attachment;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIPanGestureRecognizer *panGesture=[[UIPanGestureRecognizer alloc]initWithTarget:self action: @selector(handlePan:)];
    [self.view addGestureRecognizer:panGesture];
    
    self.animator=[[UIDynamicAnimator alloc]initWithReferenceView:self.view];
    self.gravity=[[UIGravityBehavior alloc]initWithItems:@[self.redFootball]];
    CGPoint anchorPoint=CGPointMake(self.bwFootball.center.x, self.bwFootball.center.y);
    self.attachment=[[UIAttachmentBehavior alloc]initWithItem:_redFootball attachedToAnchor:anchorPoint];
    self.collision=[[UICollisionBehavior alloc]initWithItems:@[self.redFootball]];
    self.collision.translatesReferenceBoundsIntoBoundary=YES;
    [self.attachment setDamping:0.1];
    [self.attachment setFrequency:1];
    
    [self.animator addBehavior:self.attachment];
    [self.animator addBehavior:self.collision];
    [self.animator addBehavior:self.gravity];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) handlePan:(UIPanGestureRecognizer *) gesture
{
    CGPoint tapPoint=[gesture locationInView:self.view];
    [self.attachment setAnchorPoint:tapPoint];
    self.bwFootball.center=tapPoint;
}

@end
