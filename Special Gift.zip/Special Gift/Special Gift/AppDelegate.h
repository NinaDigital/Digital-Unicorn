//
//  AppDelegate.h
//  Special Gift
//
//  Created by Leonardeta on 17/10/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

