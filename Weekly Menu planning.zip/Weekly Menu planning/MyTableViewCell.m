//
//  MyTableViewCell.m
//  Weekly Meal Planning
//
//  Created by Leonardeta on 23/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "MyTableViewCell.h"

@implementation MyTableViewCell

- (void)awakeFromNib {
        [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

}

//- (void)viewDidLoad
//{
//    ListOfReceipes *vController = nil;
//    NSArray *vControllers = [self.navigationController viewControllers];
//    for(UIViewController *vC in vControllers) {
//
//        if([vC isKindOfClass:[ListOfReceipes class]]){
//
//            vController = (ListOfReceipes*)vC;
//            break;
//        }
//    }
//    UIBarButtonItem *shareButton = [[UIBarButtonItem alloc] initWithTitle:@"Share" style:UIBarButtonItemStyleDone target:self action:@selector(saveClicked:)];
//    vController.navigationItem.rightBarButtonItem = shareButton;
//
//
//}

@end
