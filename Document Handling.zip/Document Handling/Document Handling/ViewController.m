//
//  ViewController.m
//  Document Handling
//
//  Created by Leonardeta on 21/10/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
- (IBAction)refreshDocumentsList:(id)sender;
- (IBAction)mySegmentControl:(id)sender;
- (IBAction)openDocumentIn:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *myTableView;
- (IBAction)openDocumentInWithOptions:(id)sender;
@property (strong, nonatomic) UIDocumentInteractionController *documentInteractionController;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.inDocumentsDirectory=YES;
    [self refreshDocumentsList:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshDocumentsList:) name:@"refreshView" object:nil];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.myFiles count];
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
static NSString *cellIdentifier=@"myCell";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    cell.textLabel.text=self.myFiles[indexPath.row];
    
    if (self.inDocumentsDirectory)
    {
        NSArray *paths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory=[paths objectAtIndex:0];
        NSString *myfile=[documentsDirectory stringByAppendingPathComponent:self.myFiles[indexPath.row]];
        cell.imageView.image=[UIImage imageWithContentsOfFile:myfile];
    }
    else {  //cell.imageView.image=nil;
        NSError *error;
        NSFileManager *fm=[[NSFileManager alloc]init];
        NSURL *docsURL=[fm URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:YES error:&error];
        NSURL *docsInboxURL=[docsURL URLByAppendingPathComponent:@"Inbox"];
        NSURL *fileURL=[docsInboxURL URLByAppendingPathComponent:self.myFiles[indexPath.row]];
        self.documentInteractionController=[UIDocumentInteractionController interactionControllerWithURL:fileURL];
        cell.imageView.image=[self.documentInteractionController.icons objectAtIndex:0];
    }
    return cell;
}

- (IBAction)refreshDocumentsList:(id)sender
{
if (self.inDocumentsDirectory)
{
    NSArray *paths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory=[paths objectAtIndex:0];
    NSArray *fileList=[[NSFileManager defaultManager] contentsOfDirectoryAtPath:documentsDirectory error:nil];
    self.myFiles=[NSMutableArray arrayWithCapacity:[fileList count]];
    NSString *filename;
    for (filename in fileList)
    {
        if ([[filename pathExtension] isEqualToString:@"jpg"]|| [[filename pathExtension] isEqualToString:@"pdf"])
        {
            [self.myFiles addObject:filename];
        }
    }
}
else {
    NSArray *paths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory=[paths objectAtIndex:0];
    NSString *documentsDirectoryInbox=[documentsDirectory stringByAppendingPathComponent:@"Inbox"];
    NSFileManager *fileManager=[[NSFileManager alloc]init];
    
    BOOL isDir;
    
    if([fileManager fileExistsAtPath:documentsDirectoryInbox isDirectory:&isDir])
    {
        NSArray *fileList=[[NSFileManager defaultManager] contentsOfDirectoryAtPath:documentsDirectoryInbox error:nil];
        self.myFiles=[NSMutableArray arrayWithCapacity:[fileList count]];
        NSString *filename;
        for (filename in fileList)
        {
        if ([[filename pathExtension] isEqualToString:@"jpg"]||[[filename pathExtension] isEqualToString:@"pdf"])
        {
            [self.myFiles addObject:filename];
        }
        }
    }
}
    
    [self.myTableView reloadData];
}

- (IBAction)mySegmentControl:(id)sender
{
    self.inDocumentsDirectory=!self.inDocumentsDirectory;
    [self refreshDocumentsList:nil];
}

- (IBAction)openDocumentIn:(id)sender
{
    UIButton *myButton=(UIButton *)sender;
    NSString *myUTI;
    
    NSFileManager *fm=[[NSFileManager alloc] init];
    NSError *err;
    NSURL *docsURL=[fm URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:YES error:&err];
    NSURL *fileURL;
    
    CGPoint touchPoint=[sender convertPoint:CGPointZero fromView:self.myTableView];
    NSIndexPath *indexPath=[self.myTableView indexPathForRowAtPoint:touchPoint];
    if (self.inDocumentsDirectory)
    {
        fileURL=[docsURL URLByAppendingPathComponent:self.myFiles[indexPath.row]];
        myUTI=@"public.jpeg";
    } else{
        NSLog(@"Preview a PDF");
        NSURL *docsInboxURL=[docsURL URLByAppendingPathComponent:@"Inbox"];
        fileURL=[docsInboxURL URLByAppendingPathComponent:self.myFiles[indexPath.row]];
        myUTI=@"com.adobe.pdf";
    }
    self.documentInteractionController=[UIDocumentInteractionController interactionControllerWithURL:fileURL];
    self.documentInteractionController.UTI=myUTI;
    [self.documentInteractionController setDelegate:self];
    [self.documentInteractionController presentOpenInMenuFromRect:myButton.bounds inView:myButton animated:YES];
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView beginUpdates];
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        NSError *error;
        NSFileManager *fm=[[NSFileManager alloc]init];
        NSURL *docsURL=[fm URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:YES error:&error];
        NSURL *fileURL;
        if (self.inDocumentsDirectory)
        {
            fileURL=[docsURL URLByAppendingPathComponent: self.myFiles[indexPath.row]];
            [fm removeItemAtURL:fileURL error:&error];
        }else {
            NSURL *docsInboxURL=[docsURL URLByAppendingPathComponent:@"Inbox"];
            fileURL=[docsInboxURL URLByAppendingPathComponent:self.myFiles[indexPath.row]];
            [fm removeItemAtURL:fileURL error:&error];
        }
        [self.myFiles removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath,nil] withRowAnimation:UITableViewRowAnimationTop];
    }
    [tableView endUpdates];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    NSLog(@"cell touched");
    NSFileManager *fm=[[NSFileManager alloc]init];
    NSError *err;
    NSURL *docsURL=[fm URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:YES error:&err];
    NSURL *fileURL;
    if (self.inDocumentsDirectory)
    {
        fileURL=[docsURL URLByAppendingPathComponent:self.myFiles[indexPath.row]];
    }else{
        NSURL *docsInboxURL=[docsURL URLByAppendingPathComponent:@"Inbox"];
        fileURL=[docsInboxURL URLByAppendingPathComponent:self.myFiles[indexPath.row]];
    }
    self.documentInteractionController=[UIDocumentInteractionController interactionControllerWithURL:fileURL];
    [self.documentInteractionController setDelegate:self];
    [self.documentInteractionController presentPreviewAnimated:YES];
}

- (UIViewController *) documentInteractionControllerViewControllerForPreview:(UIDocumentInteractionController *)controller
{return self;}

- (IBAction)openDocumentInWithOptions:(id)sender
{
    UIButton *myButton=(UIButton *)sender;
    NSString *myUTI;
    
    NSFileManager *fm=[[NSFileManager alloc] init];
    NSError *err;
    NSURL *docsURL=[fm URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:YES error:&err];
    NSURL *fileURL;
    
    CGPoint touchPoint=[sender convertPoint:CGPointZero fromView:self.myTableView];
    NSIndexPath *indexPath=[self.myTableView indexPathForRowAtPoint:touchPoint];
    if (self.inDocumentsDirectory)
    {
        fileURL=[docsURL URLByAppendingPathComponent:self.myFiles[indexPath.row]];
        myUTI=@"public.jpeg";
    } else{
        NSLog(@"Preview a PDF");
        NSURL *docsInboxURL=[docsURL URLByAppendingPathComponent:@"Inbox"];
        fileURL=[docsInboxURL URLByAppendingPathComponent:self.myFiles[indexPath.row]];
        myUTI=@"com.adobe.pdf";
    }
    self.documentInteractionController=[UIDocumentInteractionController interactionControllerWithURL:fileURL];
    self.documentInteractionController.UTI=myUTI;
    [self.documentInteractionController setDelegate:self];
    [self.documentInteractionController presentOpenInMenuFromRect:myButton.bounds inView:myButton animated:YES];

}
@end
