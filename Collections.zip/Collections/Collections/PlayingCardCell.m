//
//  PlayingCardCell.m
//  Collections
//
//  Created by Leonardeta on 05/10/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "PlayingCardCell.h"

@interface PlayingCardCell ()

@end

@implementation PlayingCardCell

//- (void)viewDidLoad {
//    [super viewDidLoad];
//    // Do any additional setup after loading the view.
//}
//
//- (void)didReceiveMemoryWarning {
//    [super didReceiveMemoryWarning];
//    // Dispose of any resources that can be recreated.
//}

-(void) setCardImage:(UIImage *)cardImage
{
if (_cardImage!=cardImage)
    _cardImage=cardImage;
    self.imageView.image=_cardImage;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
