//
//  ViewController.m
//  Gesture Recogniser Rotate
//
//  Created by Leonardeta on 04/10/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *cardImage;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIRotationGestureRecognizer *rotateRecogniser=[[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotateObject:)];
    [self.cardImage addGestureRecognizer:rotateRecogniser];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)rotateObject:(UIRotationGestureRecognizer *)sender
{
    NSLog(@"Rotating");
    self.cardImage.transform=CGAffineTransformMakeRotation(sender.rotation);
}
@end
