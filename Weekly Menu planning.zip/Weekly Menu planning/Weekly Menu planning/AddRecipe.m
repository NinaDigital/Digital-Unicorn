//
//  AddRecipe.m
//  Weekly Menu planning
//
//  Created by Leonardeta on 07/12/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "AddRecipe.h"
#import "AppDelegate.h"

@interface AddRecipe ()
- (IBAction)enclosureButton:(id)sender;
@property (weak, nonatomic) IBOutlet UIImageView *myEnclosureImage;
@property (weak, nonatomic) IBOutlet UITextField *titleTextField;
@property (weak, nonatomic) IBOutlet UITextField *prepTimeTextField;
@property (weak, nonatomic) IBOutlet UITextView *methodTextView;
- (IBAction)addRecipeButton:(id)sender;
@property (weak, nonatomic) IBOutlet UITextView *ingredientText;

@property (strong,nonatomic) UIImage *selectedImage;

@property NSMutableDictionary *shoppingList;
@property NSDictionary *recipies;
@property NSArray *recipeNames;
@property NSMutableArray *ingredArr;
@property NSString *recipeTitle;

@end

@implementation AddRecipe

- (void)viewDidLoad {
    [super viewDidLoad];
    self.selectedImage=nil;
    
 
    // get content from AppDelegate content and read the data into arrays
    _recipies = ((AppDelegate *)[UIApplication sharedApplication].delegate).recipies;

    _recipeNames = [_recipies allKeys];
    
    _shoppingList = ((AppDelegate *)[UIApplication sharedApplication].delegate).shoppingList;
    _ingredArr = [[NSMutableArray alloc] initWithCapacity:0];
    

    
    // Do any additional setup after loading the view.
}
-(void)viewWillDisappear:(BOOL)animated
{
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

 //===========  Take an image  ==============
- (IBAction)enclosureButton:(id)sender
{
    UIImagePickerController *imagePicker=[[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    imagePicker.sourceType=UIImagePickerControllerSourceTypeCamera;
    imagePicker.mediaTypes=[NSArray arrayWithObjects:(NSString *)kUTTypeImage, (NSString *) kUTTypeMovie, nil];
    [self presentViewController:imagePicker animated:YES completion:nil];
}

-(void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    //Code here to work with media
    [self dismissViewControllerAnimated:YES completion:nil];
    NSString *mediaType=[info objectForKey:UIImagePickerControllerMediaType];
    if ([mediaType isEqualToString:(NSString *)kUTTypeImage])
    {
        //media is an image
        self.selectedImage=[info objectForKey:UIImagePickerControllerOriginalImage];
        self.myEnclosureImage.image=self.selectedImage;
    }
    else if ([mediaType isEqualToString:(NSString *) kUTTypeMovie])
    {
        //media is a video
    }
}

-(void) imagePickerControllerDidCancel:(UIImagePickerController *)picker
{[self dismissViewControllerAnimated:YES completion:nil];}
 //=============== End Image Function ========


- (IBAction)addRecipeButton:(id)sender {
    
    NSString *recipeTitle = self.titleTextField.text;
    NSString *prepTime = self.prepTimeTextField.text;
    NSArray *ingredients = self.ingredArr;
    NSString *method = self.methodTextView.text;
    
    // put save code here for image and thumbnail
    UIImage  *image =  self.myEnclosureImage.image;
    NSData *imageData = UIImageJPEGRepresentation(image, 1.0); //UIImagePNGRepresentation(image);
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *savedImagePath = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.jpg",recipeTitle]];
    [imageData writeToFile:savedImagePath atomically:NO];
    
    //=================== make a thumbnail
    
    CGSize size = CGSizeMake(58.0, 58.0);
    UIGraphicsBeginImageContext(size);
    [image drawInRect:CGRectMake(0,0,size.width,size.height)];
    UIImage *thumbnail = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    //================= end of make thumbnail
    
    NSArray *paths1 = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentDirectory = [paths1 objectAtIndex:0];
    NSString *savedThumbnailPath = [documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@Thumbnail.jpg",recipeTitle]];
    
    NSData *thumbnailData = UIImageJPEGRepresentation(thumbnail, 1.0); //UIImagePNGRepresentation(thumbnail);
    [thumbnailData writeToFile:savedThumbnailPath atomically:NO];
    
    //  UIImage.myEnclosureImage = savedImagePath;
    
    NSDictionary *recipe = @{@"Ingredients":ingredients, @"Method":method, @"Thumbnail":savedThumbnailPath, @"BigImage":savedImagePath, @"PrepTime":prepTime};
    
    NSLog(@"%@",self.recipies);
    
    [self.recipies setValue:recipe forKey:recipeTitle];
    
}


- (IBAction)addIngredientsButton:(id)sender
{
    UIAlertController *myAlert=[UIAlertController alertControllerWithTitle:@"Ingredients" message:@"Please enter your ingredients" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *ok=[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
                       {
                           UITextField *ingredient = myAlert.textFields[0];
                           UITextField *quantity = myAlert.textFields[1];
                           UITextField *unit = myAlert.textFields[2];
            
                           self.ingredientText.text = [self.ingredientText.text stringByAppendingString:[NSString stringWithFormat:@"%@ %@ %@ \n", ingredient.text, unit.text, quantity.text]];
                            double quant = [quantity.text doubleValue];
                           [self.ingredArr addObject:@{@"Quantity":@(quant) ,@"Unit of measurement":unit.text, @"Name of ingredient":ingredient.text}];
                       }];
    UIAlertAction *cancel=[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action)
                           {}];
    
    [myAlert addAction:ok];
    [myAlert addAction:cancel];
    [myAlert addTextFieldWithConfigurationHandler:^(UITextField *textField)
     
     {textField.placeholder=@"Ingredient";}];
    [myAlert addTextFieldWithConfigurationHandler:^(UITextField *textField)
     {textField.placeholder=@"Quantity"; [textField setKeyboardType:UIKeyboardTypeNumberPad]; }];
    [myAlert addTextFieldWithConfigurationHandler:^(UITextField *textField)
     {textField.placeholder=@"Unit";}];
   
    
        [self presentViewController:myAlert animated:YES completion:nil];
}

//// Call this method somewhere in your view controller setup code.
//- (void)registerForKeyboardNotifications
//{
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(keyboardWasShown:)
//                                                 name:UIKeyboardDidShowNotification object:nil];
//    
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(keyboardWillBeHidden:)
//                                                 name:UIKeyboardWillHideNotification object:nil];
//    
//}

//// Called when the UIKeyboardDidShowNotification is sent.
//- (void)keyboardWasShown:(NSNotification*)aNotification
//{
//    NSDictionary* info = [aNotification userInfo];
//    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
//    
//    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height, 0.0);
//    scrollView.contentInset = contentInsets;
//    scrollView.scrollIndicatorInsets = contentInsets;
//    
//    // If active text field is hidden by keyboard, scroll it so it's visible
//    // Your app might not need or want this behavior.
//    CGRect aRect = self.view.frame;
//    aRect.size.height -= kbSize.height;
//    if (!CGRectContainsPoint(aRect, activeField.frame.origin) ) {
//        [self.scrollView scrollRectToVisible:activeField.frame animated:YES];
//    }
//}
//
//// Called when the UIKeyboardWillHideNotification is sent
//- (void)keyboardWillBeHidden:(NSNotification*)aNotification
//{
//    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
//    scrollView.contentInset = contentInsets;
//    scrollView.scrollIndicatorInsets = contentInsets;
//}
//- (void)textViewDidBeginEditing:(UITextView *)textView
//{
//    [self animateTextView: YES];
//}
//
//- (void)textViewDidEndEditing:(UITextView *)textView
//{
//    [self animateTextView:NO];
//}
//
//- (void) animateTextView:(BOOL) up
//{
//    const int movementDistance =50; // tweak as needed
//    const float movementDuration = 0.3f; // tweak as needed
//    int movement= movement = (up ? -movementDistance : movementDistance);
//    NSLog(@"%d",movement);
//    
//    [UIView beginAnimations: @"anim" context: nil];
//    [UIView setAnimationBeginsFromCurrentState: YES];
//    [UIView setAnimationDuration: movementDuration];
//    self.view.frame = CGRectOffset(self.inputView.frame, 0, movement);
//    [UIView commitAnimations];
//}
//
//-(void)textViewDidBeginEditing:(UITextView *)textView{
//    
//    [UIView beginAnimations:nil context:NULL];
//    [UIView setAnimationDuration:0.5];
//    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:_methodTextView cache:YES];
//    _methodTextView.frame = CGRectMake(10, 50, 300, 200);
//    [UIView commitAnimations];
//    
//    NSLog(@"Started editing target!");
//    
//}
//
//-(void)textViewDidEndEditing:(UITextView *)textView
//{
//    [UIView beginAnimations:nil context:NULL];
//    [UIView setAnimationDuration:0.5];
//    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:_methodTextView cache:YES];
//    _methodTextView.frame = CGRectMake(10, 150, 300, 200);
//    [UIView commitAnimations];
//}
/*  Code Listing 2: Implementation of the CreateAppPList Method using Cocoa Touch
 Next initialize the rootElement NSMutableDictionary with a initWithCapacity of 1.
 Create a NSError variable to capturing any errors.
?
#import "MyAppPlist.h"

@implementation MyAppPlist
@synthesize rootElement, continentElement, country, name, elementList, plistData, data, plistPath;

-(void)CreateAppPlist{
    
    //Get path of app2.plist file to be created
    plistPath = [[NSBundle mainBundle] pathForResource:@"app2" ofType:@"plsit"];
    //Create the data structure
    rootElement = [NSMutableDictionary dictionaryWithCapacity:3];
    NSError * err;
    name = @"North America";
    country = @"United States";
    
    continentElement = [NSMutableDictionary dictionaryWithObjects:[NSArray arrayWithObjects:name,country, nil] forKeys:[NSArray arrayWithObjects:@"Name", @"Country", nil ]];
    
    [rootElement setObject:continentElement forKey:@""];
    
    //Create plist file and serialize XML
    
    data = [NSPropertyListSerialization dataWithPropertyList:plistData format:NSPropertyListXMLFormat_v1_0 options:nil error:&err];
    if(data)
    {
        [data writeToFile:plistPath atomically:YES];
        
    }else{
        NSLog(@"An error has occured %@", err);
        
    }
    
}
@end
*/

/* Code Listing 3 Reading from Property List file using initWithContentsOfFile

?
-(void)readAppPlist{
    plistPath = [[NSBundle mainBundle] pathForResource:@"app" ofType:@"plist"];
    NSMutableDictionary * propertyDict = [[NSMutableDictionary alloc] initWithContentsOfFile:plistPath];
    name = [propertyDict objectForKey:@"Name"];
    country = [propertyDict objectForKey:@"Country"];
    
    //use the variables in the app
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/ //-(IBAction)addRecipeButton:(id)sender
//{

//    NSArray *paths = NSSearchPathForDirectoriesInDomains (NSDocumentDirectory, NSUserDomainMask, YES);
//    NSString *documentsPath = [paths objectAtIndex:0];
//    NSString *plistPath = [documentsPath stringByAppendingPathComponent:@"shoppingList.plist"];
//    
//    [self.titleArr addObject:self.titleTextField.text];
//    [self.prepTimeArr addObject:self.prepTimeTextField.text];
//    [self.imageArr addObject:@"image.png"];
//    [self.methodArr addObject:self.methodTextView.text];
//    [self.ingredArr addObject:self.myIngredientsTextView.text];
//}
    
//    NSDictionary *plistDict = [[NSDictionary alloc] initWithObjects: [NSArray arrayWithObjects: self.titleArr, self.prepTimeArr, self.imageArr, self.methodArr, self.ingredArr, nil] forKeys:[NSArray arrayWithObjects: @"Title", @"PrepTime",@"Image", @"Ingredients", @"Method", nil]];
//    
//    NSString *error = nil;
//    NSData *plistData = [NSPropertyListSerialization dataWithPropertyList:plistDict format:NSPropertyListXMLFormat_v1_0 options:0 error:&error];
//    
//
 //   NSData *plistData = [NSPropertyListSerialization dataFromPropertyList:plistDict format:NSPropertyListXMLFormat_v1_0 errorDescription:&error];
    
//    if(plistData)
//    {
//        [plistData writeToFile:plistPath atomically:YES];
//        NSLog(@"Data saved sucessfully");
////        alertLbl.text = @"Data saved sucessfully";
//    }
//    else
//    {
//        NSLog(@"Data not saved ");
//
 //       alertLbl.text = @"Data not saved";
 //   }
 // Data is saved in your plist and plist is saved in DocumentDirectory


    
    // =====  RETRIEVE Data from plist File:  ======

//NSArray *paths = NSSearchPathForDirectoriesInDomains (NSDocumentDirectory, NSUserDomainMask, YES);
//NSString *documentsPath = [paths objectAtIndex:0];
//NSString *plistPath = [documentsPath stringByAppendingPathComponent:@"shoppingList.plist"];

//if (![[NSFileManager defaultManager] fileExistsAtPath:plistPath])
//{
//    plistPath = [[NSBundle mainBundle] pathForResource:@"shoppingList" ofType:@"plist"];
//}
//
//NSDictionary *dict = [[NSDictionary alloc] initWithContentsOfFile:plistPath];
//self.titleArr = [dict objectForKey:@"Name"];
//self.prepTimeArr = [dict objectForKey:@"Country"];
//
// ===== end Retrieve  ====




//   REMOVE data from plist file
//    NSArray *paths = NSSearchPathForDirectoriesInDomains (NSDocumentDirectory, NSUserDomainMask, YES);
//    NSString *documentsPath = [paths objectAtIndex:0];
//    NSString *plistPath = [documentsPath stringByAppendingPathComponent:@"shoppingList.plist"];
//NSMutableDictionary *dictionary = [NSMutableDictionary dictionaryWithContentsOfFile:(NSString *)plistPath];
//
//self.titleArr = [dictionary objectForKey:@"Name"];
//self.prepTimeArr = [dictionary objectForKey:@"Country"];

//    [self.titleArr removeObjectAtIndex:indexPath.row];
//    [self.prepTimeArr removeObjectAtIndex:indexPath.row];

//[dictionary writeToFile:plistPath atomically:YES];

// ===== end Remove data   ====



// ===== UPDATE your data on Update click Action ====

//    NSArray *paths = NSSearchPathForDirectoriesInDomains (NSDocumentDirectory, NSUserDomainMask, YES);
//    NSString *documentsPath = [paths objectAtIndex:0];
//    NSString *plistPath = [documentsPath stringByAppendingPathComponent:@"shoppingList.plist"];
//
//if (![[NSFileManager defaultManager] fileExistsAtPath:plistPath])
//{
//    plistPath = [[NSBundle mainBundle] pathForResource:@"shoppingList" ofType:@"plist"];
//}
//
//
//self.plistDict = [[NSDictionary alloc] initWithContentsOfFile:plistPath];

//    [[self.plistDict objectForKey:@"Title"] removeObjectAtIndex:self.indexPath];
//    [[self.plistDict objectForKey:@"PrepTime"] removeObjectAtIndex:self.indexPath];
//    [[self.plistDict objectForKey:@"Image"] removeObjectAtIndex:self.indexPath];
//
//    [[self.plistDict objectForKey:@"Title"] insertObject:nameField.text atIndex:self.indexPath];
//    [[self.plistDict objectForKey:@"PrepTime"] insertObject:countryField.text atIndex:self.indexPath];
//    [[self.plistDict objectForKey:@"Image"] insertObject:@"egg_benedict.png" atIndex:self.indexPath];

//[self.plistDict writeToFile:plistPath atomically:YES];

//==== end update  =======

//==== write programaticaly a recipe into favorite list

//    NSString *recipeTitle = @"Usless Cake";
//    NSDictionary *ingredient1 = @{@"Quantity":@2, @"Unit of measurement":@"Cup", @"Name of ingredient":@"Flour"};
//    NSDictionary *ingredient2 = @{@"Quantity":@3, @"Unit of measurement":@"Cup", @"Name of ingredient":@"Water"};
//    NSDictionary *ingredient3 = @{@"Quantity":@1, @"Unit of measurement":@"whole", @"Name of ingredient":@"Egg"};
//    NSArray *ingredients = @[ingredient1,ingredient2,ingredient3];
//    NSString *method = @"stur mixture and bake for 20 minutes";
//    NSString *thumbnail = @"United States";
//    NSString *bigImage = @"North America";
//    NSString *prepTime = @"1 hour";
//
//    NSDictionary *recipe = @{@"Ingredients":ingredients, @"Method":method, @"Thumbnail":thumbnail, @"BigImage":bigImage, @"PrepTime":prepTime};
//
//    NSLog(@"%@",self.recipies);
//
//    [self.recipies setValue:recipe forKey:recipeTitle];
//
//    NSLog(@"%@",self.recipies);


@end
