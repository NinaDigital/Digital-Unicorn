//
//  ListOfReceipesTableViewController.m
//  Weekly Meal Planning
//
//  Created by Leonardeta on 22/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "ListOfReceipes.h"
#import "MenuDetails.h"
#import "AppDelegate.h"

@interface ListOfReceipes ()

{
    NSDictionary *recipies;
    NSArray *recipeNames;
}
@end

@implementation ListOfReceipes




- (void)viewDidLoad
{
    [super viewDidLoad];
    
       // get content from AppDelegate content and read the data into arrays
    recipies = ((AppDelegate *)[UIApplication sharedApplication].delegate).recipies;
    
    recipeNames = [recipies allKeys];

   }
-(void)viewWillAppear:(BOOL)animated
{
    recipies = ((AppDelegate *)[UIApplication sharedApplication].delegate).recipies;
    
    recipeNames = [recipies allKeys];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [recipeNames count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 78;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"cell1";
    
    
    MyTableViewCell *cell = (MyTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"cell1" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    NSString *recipeName = recipeNames[indexPath.row];
    
    cell.textLabel.text = recipeNames[indexPath.row];
    NSString *imagepath = recipies[recipeName][@"Thumbnail"];
    NSString *firstChar = [imagepath substringToIndex:1];
    
    if ([firstChar isEqualToString:@"/"])
    {
        NSData *imgData = [NSData dataWithContentsOfFile:imagepath];
        UIImage *image = [[UIImage alloc] initWithData:imgData];
        cell.imageView.image = image;
    }
    else
    {
        cell.imageView.image = [UIImage imageNamed:recipies[recipeName][@"Thumbnail"]];
    }
    
    cell.detailTextLabel.text = recipies[recipeName][@"PrepTime"];
    
    return cell;
    
}


- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Make sure your segue name in storyboard is the same as this line
    if ([[segue identifier] isEqualToString:@"MenuDetails"])
    {
        
        UITableViewCell *cell = (UITableViewCell *) sender;
        NSString *cellText = cell.textLabel.text;
        NSDictionary *dictToPass = recipies[cellText];
        
        NSLog(@"%@",cellText);
        MenuDetails *vc = (MenuDetails *)[segue destinationViewController];
        vc.recipe = dictToPass;
        vc.recipeTitle = cellText;
        
    }
    
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}

/*
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"didSelectRowAtIndexPath");
    UIAlertView *messageAlert = [[UIAlertView alloc]
     initWithTitle:@"Row Selected" message:@"You've selected a row" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
   UIAlertView *messageAlert = [[UIAlertView alloc]
                                 initWithTitle:@"Row Selected" message:[tableData objectAtIndex:indexPath.row] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    
    // Display the Hello World Message
    [messageAlert show];
 
    // Checked the selected row
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    cell.accessoryType = UITableViewCellAccessoryCheckmark;
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
*/

/*
- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"willSelectRowAtIndexPath");
    if (indexPath.row == 0) {
        return nil;
    }
    
    return indexPath;
}
*/


@end
