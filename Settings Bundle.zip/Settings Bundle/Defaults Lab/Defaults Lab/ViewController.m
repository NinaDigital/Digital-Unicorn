//
//  ViewController.m
//  Defaults Lab
//
//  Created by Leonardeta on 24/10/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
- (IBAction)displayDefaults:(id)sender;
- (IBAction)resetDefaults:(id)sender;
- (IBAction)changeDefaults:(id)sender;
@property (weak, nonatomic) IBOutlet UITextView *myTextView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSNotificationCenter *center=[NSNotificationCenter defaultCenter];
    [center addObserver:self selector:@selector(defaultsChanged:) name:(NSUserDefaultsDidChangeNotification) object:nil];
    
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    [defaults addObserver:self forKeyPath:@"facebookKey" options:NSKeyValueObservingOptionNew context:NULL];
  
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    [defaults removeObserver:self forKeyPath:@"facebookKey"];
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{NSLog(@"KVO: %@ changed property %@ to value %@", object, keyPath, change);}

-(void) defaultsChanged:(NSNotification *) notification
{
    NSLog(@"defaultsChanged");
    NSUserDefaults *defaults=(NSUserDefaults *) [notification object];
    
    NSLog(@"%@", [defaults objectForKey:@"nameKey"]);
    NSLog(@"%@", [defaults objectForKey:@"passwordKey"]);
    
}

- (IBAction)displayDefaults:(id)sender
{
    NSUserDefaults *standardDefaults=[NSUserDefaults standardUserDefaults];
    
    NSString *userName=[standardDefaults stringForKey:@"nameKey"];
    NSString *password=[standardDefaults stringForKey:@"passwordKey"];
    BOOL facebook=[standardDefaults boolForKey:@"facebookKey"];
    BOOL twitter=[standardDefaults boolForKey:@"twitterKey"];
    NSString *faction=[standardDefaults stringForKey:@"factionKey"];
    float difficulty=[standardDefaults floatForKey:@"difficultyKey"];
    
    NSString *stringToDisplay=[NSString stringWithFormat:@"Name: %@\n\nPassword: %@\n\nFacebook: %d\n\nTwitter: %d\n\nFaction: %@\n\nDifficulty: %f", userName, password, facebook, twitter, faction, difficulty];
    self.myTextView.text=stringToDisplay;
    
}

- (IBAction)resetDefaults:(id)sender
{
    UIAlertView *myAlert=[[UIAlertView alloc]initWithTitle:@"Reset" message:@"Are you sure you want to reset your settings?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
    myAlert.tag=1;
    [myAlert show];
}

- (IBAction)changeDefaults:(id)sender
{
    UIAlertView *myAlert=[[UIAlertView alloc]initWithTitle:@"Change" message:@"Are you sure you want to change your settings?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
    myAlert.tag=2;
    [myAlert show];
}

-(void) alertView:(UIAlertView *) alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
// the user clicked OK
    if (alertView.tag==1) {
        if (buttonIndex==1){
            [self resetMyDefaults];}
    }
    if (alertView.tag==2)
    { if(buttonIndex==1){[self changeMyDefaults];}
    }
}

-(void)resetMyDefaults
{
    NSLog(@"reset");
    NSString *appDomain=[[NSBundle mainBundle] bundleIdentifier];
    [[NSUserDefaults standardUserDefaults]removePersistentDomainForName:appDomain];
}

-(void) changeMyDefaults
{
    NSLog(@"Change");
    NSUserDefaults *standardDefaults=[NSUserDefaults standardUserDefaults];
    
    [standardDefaults setObject:@"Han Solo" forKey:@"nameKey"];
    [standardDefaults setObject:@"1234" forKey:@"passwordKey"];
    
    [standardDefaults setBool:YES forKey:@"facebookKey"];
    [standardDefaults setBool:NO forKey:@"twitterKey"];
    
    [standardDefaults setFloat:5 forKey:@"difficlutyKey"];
    [standardDefaults setObject:@"G" forKey:@"factionKey"];
    
}

@end
