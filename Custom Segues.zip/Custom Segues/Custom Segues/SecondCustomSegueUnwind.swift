//
//  SecondCustomSegueUnwind.swift
//  Custom Segues
//
//  Created by Leonardeta on 08/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

import UIKit

class SecondCustomSegueUnwind: UIStoryboardSegue {

    override func perform() {
        let firstVCView=destination.view
        let secondVCView=source.view
        let screenHeight=UIScreen.main.bounds.size.height
        firstVCView!.frame=firstVCView!.frame.offsetBy(dx: 0.001, dy: screenHeight)
        firstVCView!.transform=firstVCView!.transform.scaledBy(x: 0.001, y: 0.001)
        let window = UIApplication.shared.keyWindow
        window?.insertSubview(firstVCView!, aboveSubview: secondVCView!)
        
        UIView.animate(withDuration: 0.5, animations: {()-> Void in
            secondVCView!.transform=secondVCView!.transform.scaledBy(x: 0.001, y: 0.001)
            secondVCView!.frame=secondVCView!.frame.offsetBy(dx: 0.0, dy: -screenHeight)
            
            firstVCView!.transform=CGAffineTransform.identity
            firstVCView!.frame=firstVCView!.frame.offsetBy(dx: 0.0, dy: -screenHeight)
        })
        {(Finished)-> Void in
            self.source.dismiss(animated:  false, completion: nil)
        }
    }

}
