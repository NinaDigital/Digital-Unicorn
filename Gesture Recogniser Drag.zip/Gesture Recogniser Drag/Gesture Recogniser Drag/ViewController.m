//
//  ViewController.m
//  Gesture Recogniser Drag
//
//  Created by Leonardeta on 04/10/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *cardImage;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIPanGestureRecognizer *panRecogniser=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(moveObject:)];
    panRecogniser.minimumNumberOfTouches=1;
    [self.cardImage addGestureRecognizer:panRecogniser];
    
    
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)moveObject:(UIPanGestureRecognizer *)sender
{
    self.cardImage.center=[sender locationInView:_cardImage.superview];
}

@end
