//
//  MenuViewController.m
//  Weekly Meal Planning
//
//  Created by Leonardeta on 14/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "MenuViewController.h"
#import "DetailsForWeeklyMenu.h"
#import "AppDelegate.h"

@interface MenuViewController ()
@property(nonatomic, strong) NSArray *meals;
@property(nonatomic, strong) NSArray *days;
@property (nonatomic, strong) NSIndexPath *datePickerIndexPath;
@property NSMutableArray *sectionHasInlinePicker;
@property (strong, nonatomic) IBOutlet UITableView *myTable;
@property NSMutableArray *sections;
@property NSMutableArray *mealPlan;

@property NSIndexPath *selectedIndexPath;
@property NSMutableArray *addName;

@property NSMutableDictionary *shoppingList;
@property  NSDictionary *recipies;
@property  NSArray *recipeNames;

-(void)save;

@end

@implementation MenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.navigationItem.leftBarButtonItem = self.editButtonItem;
    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithTitle:@"Add Day" style:UIBarButtonItemStyleDone target:self action:@selector(addSection:)];
    self.navigationItem.rightBarButtonItem = addButton;
    
//    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addSection:)];
    
    // get content of the Plist from AppDelegate content and read the data into arrays
    _recipies = ((AppDelegate *)[UIApplication sharedApplication].delegate).recipies;
    _recipeNames = [_recipies allKeys];
    
    _shoppingList = ((AppDelegate *)[UIApplication sharedApplication].delegate).shoppingList;
    
    
    
    self.days=@[@"Monday", @"Tuesday", @"Wednesday", @"Thusday", @"Friday", @"Saturday", @"Sunday"];
   self.meals=@[@"Breakfast:", @"Elevenses:", @"Lunch:", @"Tea Time:", @"Dinner:", @"Supper:", @"Midnight feast:"];
 
    
    //self.hasInlinePicker = NO;
    self.datePickerIndexPath = nil;
    
    // Uncomment the following line to preserve selection between presentations.
    //self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    _mealPlan = ((AppDelegate *)[UIApplication sharedApplication].delegate).mealPlan;
    
    if (self.mealPlan)
    {
        self.sectionHasInlinePicker = [[NSMutableArray alloc] initWithCapacity:0];
        self.sections = self.mealPlan;
        _addName = [[NSMutableArray alloc]init];
        for (int section = 0; section < [self.sections count]; section++)
        {
            [self.addName addObject:[NSMutableArray arrayWithCapacity:0]];
            [self.sectionHasInlinePicker addObject:@NO];
            for (int row = 0; row < [self.sections[section] count]; row++)
            {
                NSString *mealName = self.sections[section][row][1];
                self.addName[section][row] = @[mealName,@"S",@""];
            }
        }
    }
    else
    {
    
    self.sectionHasInlinePicker = [@[@NO] mutableCopy];
    NSMutableArray *rows = [[NSMutableArray alloc] initWithCapacity:0];
    self.sections = [@[rows] mutableCopy];
    
    _addName = [[NSMutableArray alloc]init];
    self.addName[0] = [[NSMutableArray alloc]init];
    }

    
}

-(void)viewWillAppear:(BOOL)animated
{
//    _addName = [[NSMutableArray alloc]init];
//    self.addName[0] = [[NSMutableArray alloc]init];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [self save];
    _mealPlan = self.sections;
}

-(void)save
{
     //================================= creating the shopping.plist
    
    
    for (int section = 0; section < [self.addName count]; section++)
    {
        for (int row = 0; row < [self.addName[section] count]; row++)
        {
           // Create a new element of list
            
            if ([@"C" isEqualToString:self.addName[section][row][1]])
            {
                self.addName[section][row] = @[self.addName[section][row][0],@"S",self.addName[section][row][2]];
                NSLog(@"addName recipes -- %@", self.recipies[self.addName[section][row][0]][@"Ingredients"]);
                
                NSArray *ingredients = self.recipies[self.addName[section][row][0]][@"Ingredients"];
                
                if (ingredients)
                {
                    
                    for (int index = 0; index < [ingredients count]; index++)
                    {
                        
                        NSLog(@"Ingredient %@",self.shoppingList[ingredients[index][@"Name of ingredient"]]);
                        if (self.shoppingList[ingredients[index][@"Name of ingredient"]])
                        {
                            double quantity = [[self.shoppingList objectForKey:ingredients[index][@"Name of ingredient"]][0] doubleValue];
                            quantity += [ingredients[index][@"Quantity"] doubleValue];
                            [self.shoppingList setObject:@[@(quantity),ingredients[index][@"Unit of measurement"]] forKey:ingredients[index][@"Name of ingredient"]];
                        }
                        else
                        {
                            double quantity = 0;
                            quantity += [ingredients[index][@"Quantity"] doubleValue];
                            [self.shoppingList setObject:@[@(quantity),ingredients[index][@"Unit of measurement"]] forKey:ingredients[index][@"Name of ingredient"]];
                        }
                        
                    }
                    
                }
            }
            //   Upgarde the list
            
            else if ([@"U" isEqualToString:self.addName[section][row][1]])
            {
               
                NSLog(@"addName recipes -- %@", self.recipies[self.addName[section][row][0]][@"Ingredients"]);
               
                NSArray *ingredients = self.recipies[self.addName[section][row][0]][@"Ingredients"];
             
                if (ingredients)
                {
                    
                    for (int index = 0; index < [ingredients count]; index++)
                    {
                        
                        NSLog(@"Ingredient %@",self.shoppingList[ingredients[index][@"Name of ingredient"]]);
                        if (self.shoppingList[ingredients[index][@"Name of ingredient"]])
                        {
                            double quantity = [[self.shoppingList objectForKey:ingredients[index][@"Name of ingredient"]][0] doubleValue];
                            quantity += [ingredients[index][@"Quantity"] doubleValue];
                            [self.shoppingList setObject:@[@(quantity),ingredients[index][@"Unit of measurement"]] forKey:ingredients[index][@"Name of ingredient"]];
                        }
                        else
                        {
                            double quantity = 0;
                            quantity += [ingredients[index][@"Quantity"] doubleValue];
                            [self.shoppingList setObject:@[@(quantity),ingredients[index][@"Unit of measurement"]] forKey:ingredients[index][@"Name of ingredient"]];
                        }
                        
                    }
                    
                }
                // Delete the ingredients with Quantity=0
                
                NSArray *deleteIngredients = self.recipies[self.addName[section][row][2]][@"Ingredients"];
                if (deleteIngredients)
                {
                    
                    for (int index = 0; index < [deleteIngredients count]; index++)
                    {
                        
                        NSLog(@"Deleted Ingredient %@",self.shoppingList[deleteIngredients[index][@"Name of ingredient"]]);
                        if (self.shoppingList[deleteIngredients[index][@"Name of ingredient"]])
                        {
                            double quantity = [[self.shoppingList objectForKey:deleteIngredients[index][@"Name of ingredient"]][0] doubleValue];
                            quantity -= [deleteIngredients[index][@"Quantity"] doubleValue];
                            if (quantity > 0)
                            {
                            [self.shoppingList setObject:@[@(quantity),deleteIngredients[index][@"Unit of measurement"]] forKey:deleteIngredients[index][@"Name of ingredient"]];
                            }
                            else
                            {
                                [self.shoppingList removeObjectForKey:deleteIngredients[index][@"Name of ingredient"]];
                            }
                        }
                        else // This piece of code should never starting
                        {
                            double quantity = 0;///Aaaaaaaahhhhhhhhh!!!!!
                            quantity -= [deleteIngredients[index][@"Quantity"] doubleValue];
                            [self.shoppingList setObject:@[@(quantity),deleteIngredients[index][@"Unit of measurement"]] forKey:deleteIngredients[index][@"Name of ingredient"]];
                        }
                        
                    }
                    
                }
                
                self.addName[section][row] = @[self.addName[section][row][0],@"S",@""];
            }
            else if ([@"D" isEqualToString:self.addName[section][row][1]])
            {
                
                NSLog(@"addName recipes -- %@", self.recipies[self.addName[section][row][0]][@"Ingredients"]);
                
                // Delete the ingredients with Quantity=0
                
                NSArray *deleteIngredients = self.recipies[self.addName[section][row][2]][@"Ingredients"];
                if (deleteIngredients)
                {
                    
                    for (int index = 0; index < [deleteIngredients count]; index++)
                    {
                        
                        NSLog(@"Deleted Ingredient %@",self.shoppingList[deleteIngredients[index][@"Name of ingredient"]]);
                        if (self.shoppingList[deleteIngredients[index][@"Name of ingredient"]])
                        {
                            double quantity = [[self.shoppingList objectForKey:deleteIngredients[index][@"Name of ingredient"]][0] doubleValue];
                            quantity -= [deleteIngredients[index][@"Quantity"] doubleValue];
                            if (quantity > 0)
                            {
                                [self.shoppingList setObject:@[@(quantity),deleteIngredients[index][@"Unit of measurement"]] forKey:deleteIngredients[index][@"Name of ingredient"]];
                            }
                            else
                            {
                                [self.shoppingList removeObjectForKey:deleteIngredients[index][@"Name of ingredient"]];
                            }
                        }
                        else // This piece of code will never starting
                        {
                            double quantity = 0;///Aaaaaaaahhhhhhhhh!!!!!
                            quantity -= [deleteIngredients[index][@"Quantity"] doubleValue];
                            [self.shoppingList setObject:@[@(quantity),deleteIngredients[index][@"Unit of measurement"]] forKey:deleteIngredients[index][@"Name of ingredient"]];
                        }
                        
                    }
                    
                }
                [self.addName[section] removeObjectAtIndex:row];
                if (self.addName == nil)
                {
                    NSLog(@"crash");
                }
            }
        }
    }
    NSLog(@"Shopping List is %@",self.shoppingList);
    
    NSLog(@"saved!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    //((AppDelegate *)[UIApplication sharedApplication].delegate).shoppingList = self.shoppingList;
    
 }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section
{
    // Remove old button from re-used header
    if ([view.subviews.lastObject isKindOfClass:UIButton.class])
        [view.subviews.lastObject removeFromSuperview];
    
    //    if (section == MySectionNumberWithButton) {
    UIButton *addButton = [UIButton buttonWithType:UIButtonTypeContactAdd];
    addButton.tag = section;
    [addButton addTarget:self action:@selector(insertNewCell:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:addButton];
    
    // Place button on far right margin of header
    addButton.translatesAutoresizingMaskIntoConstraints = NO; // use autolayout constraints instead
    [addButton.trailingAnchor constraintEqualToAnchor:view.layoutMarginsGuide.trailingAnchor].active = YES;
    [addButton.bottomAnchor constraintEqualToAnchor:view.layoutMarginsGuide.bottomAnchor].active = YES;
    //    }
}

-(void)addSection:(id)sender
{
    NSMutableArray *rows = [[NSMutableArray alloc] initWithCapacity:0];
    [self.sectionHasInlinePicker addObject:@NO];
    [self.sections addObject:rows];
    [_myTable reloadData];
    [self.addName addObject:[NSMutableArray arrayWithCapacity:0]];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
//#warning Incomplete implementation, return the number of sections
    return [self.sections count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return self.days[section%7];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
//#warning Incomplete implementation, return the number of rows
    NSMutableArray *objects = [self.sections objectAtIndex:section];
    
    if ([[self.sectionHasInlinePicker objectAtIndex:section] boolValue])
        return [objects count] +1;
    return [objects count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
   
    static NSString *myCellIdentifier = @"basicCell";
    
    if ([[self.sectionHasInlinePicker objectAtIndex:indexPath.section] boolValue])
    {
        if ((indexPath.row == self.datePickerIndexPath.row + 1))
            myCellIdentifier = @"datePicker";
    }
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:myCellIdentifier];
    
    if ([myCellIdentifier isEqualToString:@"basicCell"])
    {
        NSArray *cellData = [self.sections objectAtIndex:indexPath.section] [indexPath.row];
        cell.textLabel.text = cellData[0];
        cell.detailTextLabel.text = cellData[1];
        cell.accessoryType = UITableViewCellAccessoryDetailButton;
    }
    myCellIdentifier = @"basicCell";
    return cell;
}



- (void)insertNewCell:(UIButton *) button {
    if (![[self.sectionHasInlinePicker objectAtIndex:button.tag] boolValue])
    {
        NSMutableArray *objects = [self.sections objectAtIndex:button.tag];
        if (!objects) {
            objects = [[NSMutableArray alloc] init];
        }
        NSInteger count = objects.count;
        [objects insertObject:[@[@"Meal Time",@""] mutableCopy] atIndex:count];
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:count inSection:button.tag];
        [self.sections replaceObjectAtIndex:button.tag withObject:objects];
        [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        
          self.addName[indexPath.section][indexPath.row] = @[@"",@"C",@""];

    }
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    
    if ([[self.sectionHasInlinePicker objectAtIndex:indexPath.section] boolValue])
        return NO;
    return YES;
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    NSMutableArray *objects = [self.sections objectAtIndex:indexPath.section];
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [objects removeObjectAtIndex:indexPath.row];
        
        // if created, when the element was added
        if ([@"C" isEqualToString:self.addName[indexPath.section][indexPath.row][1]])
        {
            self.addName[indexPath.section][indexPath.row] = @[@"",@"D",self.addName[indexPath.section][indexPath.row][0]];
        }
          // if saved, when the element was selected
        else if ([@"S" isEqualToString:self.addName[indexPath.section][indexPath.row][1]])
        {
            self.addName[indexPath.section][indexPath.row] = @[@"",@"D",self.addName[indexPath.section][indexPath.row][0]];
        }
        // if updated, when the element was updated
        else if ([@"U" isEqualToString:self.addName[indexPath.section][indexPath.row][1]])
        {
            self.addName[indexPath.section][indexPath.row] = @[@"",@"D",self.addName[indexPath.section][indexPath.row][2]];
        }

        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        [self.sections replaceObjectAtIndex:indexPath.section withObject:objects];
        [self save];
    }
    else if (editingStyle == UITableViewCellEditingStyleInsert)
    {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        
        // replace the index of object when deleted one
    }

}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[self.sectionHasInlinePicker objectAtIndex:indexPath.section] boolValue])
    {
        if ((indexPath.row == self.datePickerIndexPath.row + 1))
            return 162;
    }
    return 44;
}

-(void)displayInlineDatePickerForRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.myTable beginUpdates];
    
    NSInteger section = indexPath.section;
    NSInteger row = indexPath.row;
    
    if (![[self.sectionHasInlinePicker objectAtIndex:indexPath.section] boolValue])
    {
        NSArray *indexPaths = @[[NSIndexPath indexPathForRow:row + 1 inSection:section]];
        [self.myTable insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationFade];
        [self.sectionHasInlinePicker replaceObjectAtIndex:section withObject:@YES];
        self.datePickerIndexPath = indexPath;
    }
    else if ([[self.sectionHasInlinePicker objectAtIndex:section] boolValue] && self.datePickerIndexPath.row == row)
    {
        NSArray *indexPaths = @[[NSIndexPath indexPathForRow:row + 1 inSection:section]];
        [self.myTable deleteRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationFade];
        [self.sectionHasInlinePicker replaceObjectAtIndex:section withObject:@NO];
        self.datePickerIndexPath = nil;
      
     //================================= Detecting selected UIPickerView
//NSLog(@"******************* %@", [self.tableView cellForRowAtIndexPath:indexPath].detailTextLabel.text);
        
        if ([@"C" isEqualToString:self.addName[indexPath.section][indexPath.row][1]])
        {
        self.addName[indexPath.section][indexPath.row] = @[[self.tableView cellForRowAtIndexPath:indexPath].detailTextLabel.text,@"C",self.addName[indexPath.section][indexPath.row][2]];
        }
        else if ([@"S" isEqualToString:self.addName[indexPath.section][indexPath.row][1]])
        {
            self.addName[indexPath.section][indexPath.row] = @[[self.tableView cellForRowAtIndexPath:indexPath].detailTextLabel.text,@"U",self.addName[indexPath.section][indexPath.row][0]];
        }
        else if ([@"U" isEqualToString:self.addName[indexPath.section][indexPath.row][1]])
        {
            self.addName[indexPath.section][indexPath.row] = @[[self.tableView cellForRowAtIndexPath:indexPath].detailTextLabel.text,@"U",self.addName[indexPath.section][indexPath.row][2]];
        }
        else if ([@"D" isEqualToString:self.addName[indexPath.section][indexPath.row][1]])
        {
            self.addName[indexPath.section][indexPath.row] = @[[self.tableView cellForRowAtIndexPath:indexPath].detailTextLabel.text,@"U",self.addName[indexPath.section][indexPath.row][2]];
        }

        
        NSLog(@"%@",self.addName);
        
     //================================
    }
    else
    {
        NSArray *indexPaths = @[[NSIndexPath indexPathForRow:self.datePickerIndexPath.row + 1 inSection:section]];
        
        [self.myTable deleteRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationFade];
        
        if (self.datePickerIndexPath.row < row)
        {
            indexPaths = @[[NSIndexPath indexPathForRow:row inSection:section]];
        }
        else
        {
            indexPaths = @[[NSIndexPath indexPathForRow:row + 1 inSection:section]];
        }
        
        [self.myTable insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationFade];
        
        [self.sectionHasInlinePicker replaceObjectAtIndex:section withObject:@YES];
        
        if (self.datePickerIndexPath.row < row)
        {
            self.datePickerIndexPath = [NSIndexPath indexPathForRow:row - 1 inSection:section];
        }
        else
        {
            self.datePickerIndexPath = [NSIndexPath indexPathForRow:row inSection:section];
        }
    }
    
    [self.myTable deselectRowAtIndexPath:indexPath animated:YES];
    [self.myTable endUpdates];
    [self updateDatePicker];
}

-(void)updateDatePicker
{
    if (self.datePickerIndexPath != nil)
    {
        NSIndexPath *adjustIndexPath = [NSIndexPath indexPathForRow:self.datePickerIndexPath.row + 1 inSection:self.datePickerIndexPath.section];
        UITableViewCell *myDatePickerCell = [self.tableView cellForRowAtIndexPath:adjustIndexPath];
        UIDatePicker *myDatePicker = (UIDatePicker *)[myDatePickerCell viewWithTag:1];
        if (myDatePicker != nil)
        {
            [myDatePicker setDate:self.recipeNames[self.datePickerIndexPath.row] animated:NO];
        }
    }
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if ([cell.reuseIdentifier isEqualToString:@"basicCell"])
    {
        [self displayInlineDatePickerForRowAtIndexPath:indexPath];
        self.selectedIndexPath = indexPath;
    }
    else{
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    UITableViewCell *selectedCell = [_myTable cellForRowAtIndexPath:self.selectedIndexPath];
    NSMutableArray *cells = [self.sections objectAtIndex:self.selectedIndexPath.section];
    NSMutableArray *cell = [cells objectAtIndex:self.selectedIndexPath.row];
    
    if (component == 0)
    {
        selectedCell.textLabel.text = self.meals[row];
        [cell setObject:self.meals[row] atIndexedSubscript:0];
    }
    else
    {
        selectedCell.detailTextLabel.text = self.recipeNames[row];
        [cell setObject:self.recipeNames[row] atIndexedSubscript:1];
    }
    
    selectedCell.accessoryType = UITableViewCellAccessoryDetailButton;
    
    [cells replaceObjectAtIndex:self.selectedIndexPath.row withObject:cell];
    
    [self.sections replaceObjectAtIndex:self.selectedIndexPath.section withObject:cells];

}


-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (component == 0)
    {
        return self.meals.count;
    }
    else
    {
        return self.recipeNames.count;
    }
    
}

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 2;
}

-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (component == 0)
    {
        return self.meals[row];
    }
    else
    {
        return self.recipeNames[row];
    }

}

-(CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component
{
    if (component == 0)
    {
        return (self.view.frame.size.width * 30 ) / 100  ;
    }
    else
    {
        return (self.view.frame.size.width * 70 ) / 100  ;
    }
}

/*
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

- (void)tableView:(UITableView *)tableView
moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath
      toIndexPath:(NSIndexPath *)destinationIndexPath
{
    [self.objects exchangeObjectAtIndex:sourceIndexPath.row withObjectAtIndex:destinationIndexPath.row];
}
*/

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
   
    if ([[segue identifier] isEqualToString:@"DetailsForWeeklyMenu"])
    {
       UITableViewCell *cell = (UITableViewCell *) sender;
       NSLog(@"%@",cell.detailTextLabel.text);
        
       NSString *cellText = cell.detailTextLabel.text;
       NSDictionary *dictToPass = self.recipies[cellText];
       
    //   NSLog(@"%@",cellText);
        DetailsForWeeklyMenu *vc = (DetailsForWeeklyMenu *)[segue destinationViewController];
        vc.recipe = dictToPass;
        vc.recipeTitle = cellText;
        
    }

    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}

//============ Create a plist in displayInlineDatePickerForRowAtIndexPath:

//  NSLog(@"%@", self.recipies[[self.tableView cellForRowAtIndexPath:indexPath].detailTextLabel.text][@"Ingredients"]);
//    NSArray *ingredients = self.recipies[[self.tableView cellForRowAtIndexPath:indexPath].detailTextLabel.text][@"Ingredients"];

//    if (ingredients)
//    {
//        for (int index = 0; index < [ingredients count]; index++)
//        {
//
//            NSLog(@"ingredient %@",self.shoppingList[ingredients[index][@"Name of ingredient"]]);
//            if (self.shoppingList[ingredients[index][@"Name of ingredient"]])
//            {
//                NSInteger quantity = [[self.shoppingList objectForKey:ingredients[index][@"Name of ingredient"]] integerValue];
//                quantity += [ingredients[index][@"Quantity"] integerValue];
//                [self.shoppingList setObject:@(quantity) forKey:ingredients[index][@"Name of ingredient"]];
//            }
//            else
//            {
//                NSInteger quantity = 0;
//                quantity += [ingredients[index][@"Quantity"] integerValue];
//                [self.shoppingList setObject:@(quantity) forKey:ingredients[index][@"Name of ingredient"]];
//            }
//
//        }
//        NSLog(@"shoppingList is %@",self.shoppingList);
//    }

//=========================

@end
