//
//  ListOfReceipes.h
//  Weekly Meal Planning
//
//  Created by Leonardeta on 22/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTableViewCell.h"
@interface ListOfReceipes : UITableViewController <UITableViewDataSource, UITableViewDelegate>


@end
