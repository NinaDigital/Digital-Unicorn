//
//  ViewController.m
//  Weekly Meal Planning
//
//  Created by Leonardeta on 09/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "DetailsForWeeklyMenu.h"
#import "MenuViewController.h"

@interface DetailsForWeeklyMenu ()

@end

@implementation DetailsForWeeklyMenu

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    _myRecipeTitle.text = self.recipeTitle;
    _myBigImage.image = [UIImage imageNamed:self.recipe[@"BigImage"]];
    NSMutableString *ingredients = [NSMutableString stringWithCapacity:0];
    for (int i = 0; i<[self.recipe[@"Ingredients"] count]; i++)
    {
        ingredients = [NSMutableString stringWithFormat:@"%@ %@ %@ %@ \n"
                       ,ingredients,
                       self.recipe[@"Ingredients"][i][@"Quantity"],
                       self.recipe[@"Ingredients"][i][@"Unit of measurement"],
                       self.recipe[@"Ingredients"][i][@"Name of ingredient"]];
    }
    _myIngredients.text = ingredients;
    _myMethod.text = [_recipe valueForKey:@"Method"];

    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    // Dispose of any resources that can be recreated.
}

@end
