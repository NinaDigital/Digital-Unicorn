//
//  ViewController.swift
//  PressTheButton
//
//  Created by Leonardeta on 02/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var myLabel: UILabel!
    @IBAction func myButton(_ sender: AnyObject) {
        myLabel.text="The Second Text View"
        myLabel.backgroundColor=UIColor.blue
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

