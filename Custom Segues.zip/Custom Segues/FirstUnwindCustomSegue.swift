//
//  FirstUnwindCustomSegue.swift
//  Custom Segues
//
//  Created by Leonardeta on 08/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

import UIKit

class FirstUnwindCustomSegue: UIStoryboardSegue {

    override func perform() {
        let secondVCView=self.source.view
        let firstVCView=self.destination.view
        
        let screenHeight=UIScreen.main.bounds.size.height
        
        let window=UIApplication.shared.keyWindow
        window?.insertSubview(firstVCView!, aboveSubview: secondVCView!)
        
        UIView.animate(withDuration: 0.4, animations: {()-> Void in
        firstVCView!.frame=firstVCView!.frame.offsetBy(dx: 0.0, dy: screenHeight)
        secondVCView!.frame=secondVCView!.frame.offsetBy(dx: 0.0, dy: screenHeight)
        })
        { (Finished)-> Void in
        self.source.dismiss(animated: false, completion: nil)}
    }
    
    
    
}
