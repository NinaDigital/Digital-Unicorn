//
//  SecondCustomSegue.swift
//  Custom Segues
//
//  Created by Leonardeta on 08/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

import UIKit

class SecondCustomSegue: UIStoryboardSegue {
    
    override func perform() {
        let firstVCView=source.view
        let secondVCView=destination.view
        
        let window=UIApplication.shared.keyWindow
        window?.insertSubview(secondVCView!, belowSubview: firstVCView!)
        secondVCView!.transform=secondVCView!.transform.scaledBy(x: 0.001, y: 0.001)
        
        UIView.animate(withDuration: 0.5, animations: {()->Void in firstVCView!.transform=secondVCView!.transform.scaledBy(x: 0.001, y: 0.001)})
        {(Finished)->Void in
            UIView.animate(withDuration: 0.5, animations: {()-> Void in secondVCView!.transform=CGAffineTransform.identity}, completion:{(Finished)->Void in
            firstVCView!.transform=CGAffineTransform.identity
                self.source.present(self.destination as UIViewController, animated: false, completion: nil)
            })
        }
    }

}
