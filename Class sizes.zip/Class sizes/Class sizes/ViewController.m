//
//  ViewController.m
//  Class sizes
//
//  Created by Leonardeta on 27/09/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *aLabel;
- (IBAction)helloButton:(id)sender;
- (IBAction)goodbyeButton:(id)sender;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)helloButton:(id)sender
{
    if ([self.aLabel.text isEqual:@"Hello"])
{self.aLabel.text=@"Hello all";}
else {self.aLabel.text= @"Hello";}
}

- (IBAction)goodbyeButton:(id)sender
{
self.aLabel.text= @"Goodbye";
}
@end
