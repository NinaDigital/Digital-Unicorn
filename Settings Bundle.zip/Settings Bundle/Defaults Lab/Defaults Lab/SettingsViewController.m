//
//  SettingsViewController.m
//  Defaults Lab
//
//  Created by Leonardeta on 24/10/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "SettingsViewController.h"

@interface SettingsViewController ()
- (IBAction)textFieldDoneEditing:(id)sender;

- (IBAction)buttonPressed:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *userNameLabel;
@property (weak, nonatomic) IBOutlet UITextField *passwordLabel;
@property (weak, nonatomic) IBOutlet UISwitch *facebookSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *twitterSwitch;
@property (weak, nonatomic) IBOutlet UISlider *difficultySlider;
@property (weak, nonatomic) IBOutlet UISegmentedControl *factionSegment;

@end

@implementation SettingsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSUserDefaults *standardDefaults=[NSUserDefaults standardUserDefaults];
    
    NSString *userName=[standardDefaults stringForKey:@"nameKey"];
    NSString *password=[standardDefaults stringForKey:@"passwordKey"];
    BOOL facebook=[standardDefaults boolForKey:@"facebookKey"];
    BOOL twitter=[standardDefaults boolForKey:@"twitterKey"];
    NSString *faction=[standardDefaults stringForKey:@"factionKey"];
    float difficulty=[standardDefaults floatForKey:@"difficultyKey"];
    
    self.userNameLabel.text=userName;
    self.passwordLabel.text=password;
    
    self.facebookSwitch.on=facebook;
    self.twitterSwitch.on=twitter;
    
    if ([faction isEqualToString:@"B"])
    {
        self.factionSegment.selectedSegmentIndex=0;
    }
    else {
    
        self.factionSegment.selectedSegmentIndex=1;
    }
    self.difficultySlider.value=difficulty;
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
////#warning Incomplete implementation, return the number of sections
//    return 4;
//}

//- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
////#warning Incomplete implementation, return the number of rows
//    return 1;
//}

/*
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:<#@"reuseIdentifier"#> forIndexPath:indexPath];
    
    // Configure the cell...
    
    return cell;
}
*/

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)textFieldDoneEditing:(id)sender
{
    [sender resignFirstResponder];
}

- (IBAction)buttonPressed:(id)sender
{
    NSUserDefaults *standardDefaults=[NSUserDefaults standardUserDefaults];
    
    [standardDefaults setObject:self.userNameLabel.text forKey:@"nameKey"];
    [standardDefaults setObject:self.passwordLabel.text forKey:@"passwordKey"];
    
    [standardDefaults setBool:self.facebookSwitch.isOn forKey:@"facebookKey"];
    [standardDefaults setBool:self.twitterSwitch.isOn forKey:@"twitterKey"];
    
    if (self.factionSegment.selectedSegmentIndex==0)
    {
        [standardDefaults setObject:@"B" forKey:@"factionKey"];}
    else if (self.factionSegment.selectedSegmentIndex==1)
    {
        [standardDefaults setObject:@"G" forKey:@"factionKey"];
    }
    [standardDefaults setFloat:self.difficultySlider.value forKey:@"difficultyKey"];
    [self dismissViewControllerAnimated:YES completion:nil];
}


@end
