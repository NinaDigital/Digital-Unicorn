//
//  main.swift
//  Core Data with two entities
//
//  Created by Leonardeta on 10/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

import Foundation
import CoreData

// Create the container
let container=NSPersistentContainer(name:"MyNextModel")
container.loadPersistentStores(completionHandler: {(storeDescription, error) in
    if let error=error as NSError?
    {
        //Replace this implementation with code to handle the error appropriately.
        // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        
        /* Typical reasons for an error here include:
         * The parent directory does not exist, cannot be created, or disallows writing.
         *The persistent store is not accessibble, due to permissions or data protection when the device is locked.
         * The device is out of space.
         * The store coulfdnot be migrated to the current model version.
         * Check the error message to determine what the actual problem was.
         */
        fatalError("Unresolved error \(error), \(error.userInfo)")
    }
})
// Get the MOC
let managedObjectContext=container.viewContext
print("Persistent store initialized")

print("Persistent store initialized");

let computersToAdd =
    [
        [1,"MacBookAir13.png","MacBook Air 13 inch", 849.00, "Apple", "Laptop"],
        [2,"MacBookAir11.png","MacBook Air 11 inch", 749.00, "Apple", "Laptop"],
        [3,"MacBookAPro13.png","MacBook Pro", 999.00, "Apple", "Laptop"],
        [4,"MacBookProRetina13.png","MacBook Pro Retina 13 inch", 1099.00, "Apple", "Laptop"],
        [5,"MacBookProRetina15.png","MacBook Pro Retina 15 inch", 1699.00, "Apple", "Laptop"],
        [6,"Macmini.png","Mac mini", 499.00, "Apple", "Desktop"],
        [7,"MacminiwithOSXServer.png","Mac mini with OS X Server", 849.00, "Apple", "Desktop"],
        [8,"iMac215inch.png","iMac 21.5 inch", 1149.00, "Apple", "Desktop"],
        [9,"iMac27inch.png","iMac 27 inch", 1599.00, "Apple", "Desktop"],
        [10,"MacProQuadCore.png","Mac Pro Quad-Core", 2499.00, "Apple", "Desktop"],
        [11,"MacPro6Core.png","Mac Pro 6-Core", 3299.00, "Apple", "Desktop"]];

let desktopType=NSEntityDescription.insertNewObject(forEntityName: "Type", into: managedObjectContext)
desktopType.setValue("Desktop", forKey: "usage")
let laptopType=NSEntityDescription.insertNewObject(forEntityName: "Type", into: managedObjectContext)
laptopType.setValue("Laptop", forKey: "usage")

for computers in computersToAdd
{
    var newComputer=NSEntityDescription.insertNewObject(forEntityName: "Computers", into: managedObjectContext)
    
    newComputer.setValue(computers[0], forKey: "id")
    newComputer.setValue(computers[1], forKey: "image")
    newComputer.setValue(computers[2], forKey: "name")
    newComputer.setValue(computers[3], forKey: "price")
    newComputer.setValue(computers[4], forKey: "supplier")
    
    if computers[5] as? String=="Laptop"
    {newComputer.setValue(laptopType, forKey: "type")}
    else {newComputer.setValue(desktopType, forKey: "type")}
    
    print("Creating \(computers[0]), \(computers[1]), \(computers[2]), \(computers[3]), \(computers[4])")
}

// Save the managed object context

if managedObjectContext.hasChanges{
    do {
        try managedObjectContext.save()
        print("managedObjectContext successfully saved!")
    }
    catch
    {
        // Replace this implimentation with code to handle the error appropriately.
        // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        
        let nserror=error as NSError
        print("Unresolved error \(nserror), \(nserror.userInfo)")
        abort()
    }
}

let macs=laptopType.value(forKeyPath:"computers") as? Set<NSManagedObject>
for mac in macs!
{
if let name=mac.value(forKey: "name"), let usage=laptopType.value(forKey: "usage")
{print("The model \(name) is a \(usage) type")}
}

managedObjectContext.delete(desktopType) // delete all desktops
managedObjectContext.delete(laptopType) // delete all laptops

print("about to delete the following objects from POS \(managedObjectContext.deletedObjects)")

if managedObjectContext.hasChanges{
    do {
        try managedObjectContext.save()
        print("managedObjectContext successfully saved! (again)")
    }
    catch
    {
        // Replace this implimentation with code to handle the error appropriately.
        // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        
        let nserror=error as NSError
        print("Unresolved error \(nserror), \(nserror.userInfo)")
        abort()
    }
}

let fetchRequest=NSFetchRequest<NSManagedObject>(entityName: "Type")
fetchRequest.entity=NSEntityDescription.entity(forEntityName: "Type", in: managedObjectContext)
fetchRequest.predicate=NSPredicate(format:"(SUBQUERY(computers,$x,$x.price > 1000).@count>3)")

do{
let types=try managedObjectContext.fetch(fetchRequest as! NSFetchRequest<NSFetchRequestResult>)
    for type in types{
    print("computer count is  \(type)")
        if let macs=(type as AnyObject).value(forKeyPath: "computers") as? Set<NSManagedObject>
        {
        for mac in macs
        {
            if let name=mac.value(forKeyPath:"name"), let usage=(type as AnyObject).value(forKeyPath: "usage")
            {print("The model \(name) is a \(usage) type as a result of a SUBQUERY")}
            }
        }
    }
}
catch {
    let nserror=error as NSError
    print("Error fetching the computers entities: \(nserror), \(nserror.userInfo)")
    abort()
}


