//
//  ViewController.swift
//  Custom Segues
//
//  Created by Leonardeta on 08/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let swipeGestureRecognizer: UISwipeGestureRecognizer=UISwipeGestureRecognizer(target: self, action: #selector(ViewController.showSecondViewController))
        swipeGestureRecognizer.direction=UISwipeGestureRecognizerDirection.up
        self.view.addGestureRecognizer(swipeGestureRecognizer)
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
func showSecondViewController()
{self.performSegue(withIdentifier: "idFirstSegue", sender: self)}
    
    @IBAction func returnToScreen1(sender: UIStoryboardSegue)
    {
    
    }

}

