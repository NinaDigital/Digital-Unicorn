//
//  MyTableViewCell.h
//  Weekly Meal Planning
//
//  Created by Leonardeta on 23/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ListOfReceipes.h"
@interface MyTableViewCell : UITableViewCell
@property UINavigationController *navigationController;
@end
