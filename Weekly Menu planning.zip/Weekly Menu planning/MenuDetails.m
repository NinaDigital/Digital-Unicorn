//
//  MenuDetailsViewController.m
//  Weekly Meal Planning
//
//  Created by Leonardeta on 23/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "MenuDetails.h"
#import "ListOfReceipes.h"

@interface MenuDetails ()

@end

@implementation MenuDetails


- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIBarButtonItem *shareButton = [[UIBarButtonItem alloc] initWithTitle:@"Share" style:UIBarButtonItemStyleDone target:self action:@selector(saveClicked:)];
        self.navigationItem.rightBarButtonItem = shareButton;
    
    // Do any additional setup after loading the view.
    
    _myRecipeTitle.text = self.recipeTitle;
    _myBigImage.image = [UIImage imageNamed:self.recipe[@"BigImage"]];
    NSMutableString *ingredients = [NSMutableString stringWithCapacity:0];
    for (int i = 0; i<[self.recipe[@"Ingredients"] count]; i++)
    {
        ingredients = [NSMutableString stringWithFormat:@"%@ %@ %@ %@ \n"
                       ,ingredients,
                       self.recipe[@"Ingredients"][i][@"Quantity"],
                       self.recipe[@"Ingredients"][i][@"Unit of measurement"],
                       self.recipe[@"Ingredients"][i][@"Name of ingredient"]];
    }
    _myIngredients.text = ingredients;
    _myMethod.text = [_recipe valueForKey:@"Method"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)saveClicked:(id)sender
{
    UIAlertController *myAlert=[UIAlertController alertControllerWithTitle:@"Recipe of the DAY" message:@"I want to post it on:" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *facebook=[UIAlertAction actionWithTitle:@"Facebook" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
                          {
                              if ([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook])
                              { NSLog(@"Facebook is available");
                                  SLComposeViewController *facebookPostVC = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
                                  
                                NSMutableString *myText = [NSMutableString stringWithCapacity:0];
                                myText = [NSMutableString stringWithFormat:@"Ingredients: %@\n  %@\n Method:\n%@", myText, _myIngredients.text, _myMethod.text];
                                  
                                
                                UIImage *myImage = [UIImage imageNamed:[_recipe valueForKey:@"BigImage"]];
                            
                                [facebookPostVC setInitialText:myText];
                                [facebookPostVC addImage:myImage];
                                  
                                  [facebookPostVC setCompletionHandler:^(SLComposeViewControllerResult result)
                                   {
                                       switch (result){
                                           case SLComposeViewControllerResultCancelled:
                                               NSLog(@"Post Canceled");
                                               break;
                                           case SLComposeViewControllerResultDone:
                                               NSLog(@"Post Successful");
                                               break;
                                           default: break;
                                       }
                                   }];
                                  
                                  [self presentViewController:facebookPostVC animated:YES completion:nil];
                              }
                              
                              else {NSLog(@"Facebook is not available");}

                          }];
    
    UIAlertAction *twitter=[UIAlertAction actionWithTitle:@"Twitter" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
                          {
                              SLComposeViewController *twitterPostVC = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
                              
                              NSMutableString *myText = [NSMutableString stringWithCapacity:0];
                              myText = [NSMutableString stringWithFormat:@"Ingredients: %@\n  %@\n Method:\n%@", myText,_myIngredients.text,_myMethod.text];
                              UIImage *myImage = [UIImage imageNamed:[_recipe valueForKey:@"BigImage"]];
                              
                              [twitterPostVC setInitialText:myText];
                              [twitterPostVC addImage:myImage];
                              [self presentViewController:twitterPostVC animated:YES completion:nil];

                                                        }];
    
    UIAlertAction *cancel=[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action)
                           {}];
    
    [myAlert addAction:facebook];
    [myAlert addAction:twitter];
    [myAlert addAction:cancel];
    
    [self presentViewController:myAlert animated:YES completion:nil];
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
