//
//  MenuViewController.h
//  Weekly Meal Planning
//
//  Created by Leonardeta on 14/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailsForWeeklyMenu.h"

@interface MenuViewController : UITableViewController <UIPickerViewDelegate, UIPickerViewDataSource, UITableViewDataSource, UITableViewDelegate>



@end
