//
//  PlayingCarHeaderCollectionReusableView.h
//  Collections
//
//  Created by Leonardeta on 05/10/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayingCardHeader : UICollectionReusableView
@property (weak, nonatomic) IBOutlet UIImageView *suitImageView;
@property (weak, nonatomic) IBOutlet UILabel *deckLabel;
-(void) setDeckText: (NSString *) text;

@end
