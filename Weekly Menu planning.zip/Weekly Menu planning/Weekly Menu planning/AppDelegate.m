//
//  AppDelegate.m
//  Weekly Menu planning
//
//  Created by Leonardeta on 23/11/2016.
//  Copyright © 2016 Leonardeta. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

- (void)copyPListsIfNeeded:(NSString *) pListName;
- (NSString *)getPListPath:(NSString *) pListName;
@property NSString *recipePath;
@property NSString *shoppingPath;
@property NSString *mealPlanPath;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [self copyPListsIfNeeded:@"shoppingList.plist"];
    [self copyPListsIfNeeded:@"recipeDictionary.plist"];
    [self copyPListsIfNeeded:@"myFavorite.plist"];
    [self copyPListsIfNeeded:@"mealPlan.plist"];
    
    _shoppingPath = [self getPListPath:@"shoppingList.plist"];
    _recipePath = [self getPListPath:@"recipeDictionary.plist"];
    _mealPlanPath = [self getPListPath:@"mealPlan.plist"];

//    NSString *favoritePath = [self getPListPath:@"myFavorite.plist"];
    
    // Load the file content and read the data into arrays
    _recipies = [[NSMutableDictionary alloc] initWithContentsOfFile:self.recipePath];
    _shoppingList = [[NSMutableDictionary alloc] initWithContentsOfFile:self.shoppingPath];
    _mealPlan = [[NSMutableArray alloc] initWithContentsOfFile:self.mealPlanPath];
    
    // create two Dictionaries from the main plist (recipeDictionary.plist) which includes all the ingredients(nOfI) and all the units (nOfU)
    
    NSMutableDictionary *nOfI = [[NSMutableDictionary alloc] initWithCapacity:0];
    NSMutableDictionary *nOfU = [[NSMutableDictionary alloc] initWithCapacity:0];
    
    for (NSDictionary *recipe in [self.recipies allValues])
    {
        
        for (int items = 0; items <[recipe[@"Ingredients"] count] ; items++)
        {
            NSString *name = recipe[@"Ingredients"][items][@"Name of ingredient"];
            if (name)
            {
                [nOfI setValue:@"" forKey:name];
            }
            NSString *unit = recipe[@"Ingredients"][items][@"Unit of measurement"];
            if (unit)
                
            {
                [nOfU setValue:@"" forKey:unit];
            }
        }
    }
    
    self.shoppingItems = [nOfI allKeys];
    self.shoppingUnits = [nOfU allKeys];
    
    NSLog(@"shopping items %@",self.shoppingItems);
    NSLog(@"shopping units %@",self.shoppingUnits);
    
//    _shoppingItems = [[NSMutableDictionary alloc] initWithContentsOfFile:favoritePath];
//    _shoppingUnits = [[NSMutableDictionary alloc] initWithContentsOfFile:favoritePath];
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    [_shoppingList writeToFile:self.shoppingPath atomically:YES];
    [_recipies writeToFile:self.recipePath atomically:YES];
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    
    // save and write to shopping.plist
    
   // NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
   // NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
   // NSString *docfilePath = [basePath stringByAppendingPathComponent:@"shoppingList.plist"];

   // NSString *recipeFilePath = [basePath stringByAppendingPathComponent:@"recipeDictionary.plist"];
    
    [_shoppingList writeToFile:self.shoppingPath atomically:YES];
    [_recipies writeToFile:self.recipePath atomically:YES];
    [_mealPlan writeToFile:self.mealPlanPath atomically:YES];

}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    [_shoppingList writeToFile:self.shoppingPath atomically:YES];
    [_recipies writeToFile:self.recipePath atomically:YES];
    [_mealPlan writeToFile:self.mealPlanPath atomically:YES];
}

//===== It will copy your Plist in doc directory, then you can used it from doc directory.


- (void)copyPListsIfNeeded:(NSString *) pListName
{
    BOOL success;
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    success = [fileManager fileExistsAtPath:[self getPListPath:pListName]];
    if(success)
    {
        return;// If exists, then do nothing.
    }
    //Get plists from bundle & copy it to the doc directory.
    NSString *databasePath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:pListName];
    [fileManager copyItemAtPath:databasePath toPath:[self getPListPath:pListName] error:nil];
}

//Check DB in doc directory.
- (NSString *)getPListPath:(NSString *) pListName
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory , NSUserDomainMask, YES);
    NSString *documentsDir = [paths objectAtIndex:0];
    return [documentsDir stringByAppendingPathComponent:pListName];
}
//===================


@end
